function App() {
  const student = {
    id: 101,
    name: "Mounika",
    branch: "AI & DS"
  };

  return (
    <div>
      <h2>Student Information</h2>
      <p>ID: {student.id}</p>
      <p>Name: {student.name}</p>
      <p>Branch: {student.branch}</p>
    </div>
  );
}

export default App;